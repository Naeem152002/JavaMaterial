package login.register;

import ui.RegisterUi;

public class LoginRegister {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new RegisterUi(); 
	}
}
