package dto;

import lombok.Data;
import lombok.Getter;

@Data
public class Dto {
		private String name,email,mobile,pass;
}
